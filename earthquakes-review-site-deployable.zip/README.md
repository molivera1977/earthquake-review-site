# Earthquakes – Story Review (Deployable)

Preconfigured for GitHub Pages at https://molivera1977.github.io/earthquakes-review-site/

## Commands
npm install
npm run dev
npm run build
npm run deploy
